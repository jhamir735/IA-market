/**
 * ===========================================
 * BASE DE DATOS DE PRODUCTOS - CONECTADA A API
 * ===========================================
 * 
 * Este archivo contiene la base de datos central de productos para AI Market.
 * Ahora se conecta al backend para obtener datos reales de la base de datos.
 * 
 * Estructura de cada producto:
 * - id: Identificador único del producto
 * - name: Nombre del producto
 * - price: Precio en soles peruanos
 * - category: Categoría del producto (para filtros)
 * - brand: Marca del producto
 * - img: URL de la imagen del producto
 * - description: Descripción opcional del producto
 */

// Variables globales
let productDatabase = [];
let catalogCategories = [];

/**
 * Carga productos desde la API del backend
 */
async function loadProductsFromAPI() {
    try {
        console.log('🔄 Cargando productos desde API...');

        // RUTA CORRECTA PARA PRODUCTOS (Doble API)
        const response = await fetch('http://localhost:8080/api/api/productos', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        
        // CORRECCIÓN VITAL: Aceptar el array directo de Java
        const productos = Array.isArray(data) ? data : (data.productos || []);

        if (productos.length === 0) {
            throw new Error('No hay productos disponibles en la base de datos');
        }

        const uniqueProducts = new Map();
        productos.forEach(producto => {
            if (!uniqueProducts.has(producto.id)) {
                const categoryName = producto.categoria || producto.categoria_nombre || 'General';
                const categorySlug = categoryName.toLowerCase().replace(/\s+/g, '-');

                uniqueProducts.set(producto.id, {
                    id: producto.id,
                    name: producto.nombre,
                    price: parseFloat(producto.precio),
                    category: categorySlug,
                    categoryId: producto.categoria_id || null,
                    categoryName: categoryName,
                    categorySlug: categorySlug,
                    brand: producto.marca || 'N/A',
                    // CORRECCIÓN: Ajustamos urlImagen que es como lo envía tu Java
                    img: producto.urlImagen || producto.url_imagen || 'https://via.placeholder.com/300x300?text=Sin+Imagen',
                    description: ''
                });
            }
        });

        productDatabase = Array.from(uniqueProducts.values());
        window.productDatabase = productDatabase;

        console.log('✅ Productos cargados desde API:', productDatabase.length);

        window.dispatchEvent(new CustomEvent('productsLoaded', {
            detail: { products: productDatabase }
        }));

        return productDatabase;
    } catch (error) {
        console.error('❌ Error cargando productos desde API:', error);
        productDatabase = [];
        window.productDatabase = productDatabase;
        return productDatabase;
    }
}

/**
 * Carga categorías desde la API del backend
 */
async function loadCategoriesFromAPI() {
    try {
        console.log('🔄 Cargando categorías desde API...');
        
        // RUTA CORRECTA PARA CATEGORÍAS (Un solo API)
        const response = await fetch('http://localhost:8080/api/categorias');

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        
        // CORRECCIÓN VITAL: Aceptar el array directo de Java
        const categorias = Array.isArray(data) ? data : (data.categorias || []);
        
        catalogCategories = categorias;
        window.catalogCategories = catalogCategories;

        console.log('✅ Categorías cargadas desde API:', categorias.length);

        window.dispatchEvent(new CustomEvent('categoriesLoaded', {
            detail: { categories: categorias }
        }));

        return categorias;
    } catch (error) {
        console.error('❌ Error cargando categorías desde API:', error);
        return [];
    }
}

/**
 * Inicializa la carga de datos al cargar la página
 */
document.addEventListener('DOMContentLoaded', function () {
    console.log('🚀 Inicializando carga de productos...');
    loadProductsFromAPI();
    loadCategoriesFromAPI();
});

// Exportar funciones para uso global
window.loadProductsFromAPI = loadProductsFromAPI;
window.loadCategoriesFromAPI = loadCategoriesFromAPI;
window.productDatabase = productDatabase;
window.catalogCategories = catalogCategories;