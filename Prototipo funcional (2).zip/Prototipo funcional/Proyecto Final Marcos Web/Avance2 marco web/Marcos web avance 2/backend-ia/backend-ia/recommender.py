import random
import logging
from typing import List, Dict, Any, Optional
from db import db

logger = logging.getLogger(__name__)

def generar_canasta(usuario_id: int, presupuesto: float, productos_deseados: List[int] = None, preferencias_usuario: Dict = None) -> Dict[str, Any]:
    """
    Genera una canasta optimizada usando IA basada en:
    - Presupuesto del usuario
    - Productos deseados específicos
    - Preferencias de marcas, dietas y categorías
    """
    try:
        logger.info(f"Generando canasta para usuario {usuario_id} con presupuesto {presupuesto}")
        
        # Obtener productos de la base de datos
        productos = obtener_productos_disponibles()
        
        if not productos:
            return crear_respuesta_vacia(presupuesto)
        
        logger.info(f"Total productos disponibles: {len(productos)}")
        
        # Aplicar filtros de preferencias (manejar errores silenciosamente)
        try:
            productos_filtrados = aplicar_filtros_preferencias(productos, preferencias_usuario)
            logger.info(f"Productos después de filtrar: {len(productos_filtrados)}")
        except Exception as e:
            logger.warning(f"Error aplicando filtros: {e}, usando todos los productos")
            productos_filtrados = productos
        
        # Obtener historial de compras del usuario para mejorar recomendaciones
        try:
            historial_compras = obtener_historial_usuario(usuario_id)
            logger.info(f"Historial de compras: {historial_compras}")
        except Exception as e:
            logger.warning(f"Error obteniendo historial: {e}, usando simulado")
            historial_compras = [1, 2, 3, 7, 11]
        
        # Incluir productos deseados primero
        canasta_productos = []
        costo_actual = 0.0
        
        if productos_deseados:
            for producto_id in productos_deseados:
                producto = next((p for p in productos_filtrados if p['id'] == producto_id), None)
                if producto and costo_actual + producto['precio'] <= presupuesto:
                    canasta_productos.append({
                        **producto,
                        'es_deseado': True,
                        'score_relevancia': 1.0
                    })
                    costo_actual += producto['precio']
        
        # Priorizar productos del historial si no hay productos deseados
        productos_prioritarios = []
        if not productos_deseados and historial_compras:
            for producto_id in historial_compras[:3]:  # Top 3 productos más comprados
                producto = next((p for p in productos_filtrados if p['id'] == producto_id), None)
                if producto and costo_actual + producto['precio'] <= presupuesto:
                    productos_prioritarios.append({
                        **producto,
                        'es_deseado': False,
                        'es_del_historial': True,
                        'score_relevancia': 0.9
                    })
                    costo_actual += producto['precio']
        
        canasta_productos.extend(productos_prioritarios)
        
        # Generar recomendaciones usando algoritmo de IA
        presupuesto_restante = presupuesto - costo_actual
        logger.info(f"Presupuesto restante: {presupuesto_restante}")
        logger.info(f"Productos en canasta actual: {len(canasta_productos)}")
        
        productos_recomendados = generar_recomendaciones_ia(
            productos_filtrados, 
            canasta_productos, 
            presupuesto_restante,
            usuario_id,
            historial_compras
        )
        
        logger.info(f"Productos recomendados generados: {len(productos_recomendados)}")
        canasta_productos.extend(productos_recomendados)
        
        # Calcular totales
        total = sum(p['precio'] for p in canasta_productos)
        ahorro = max(0, presupuesto - total)
        porcentaje_ahorro = (ahorro / presupuesto * 100) if presupuesto > 0 else 0
        
        return {
            "productos": canasta_productos,
            "total": round(total, 2),
            "presupuesto": presupuesto,
            "ahorro": round(ahorro, 2),
            "porcentaje_ahorro": round(porcentaje_ahorro, 2),
            "productos_recomendados": len([p for p in canasta_productos if not p.get('es_deseado', False)]),
            "productos_deseados": len([p for p in canasta_productos if p.get('es_deseado', False)])
        }
        
    except Exception as e:
        logger.error(f"Error generando canasta: {e}")
        return crear_respuesta_vacia(presupuesto)

def obtener_productos_disponibles() -> List[Dict]:
    """Obtiene todos los productos disponibles de la base de datos"""
    try:
        query = """
        SELECT 
            p.id,
            p.nombre,
            p.precio,
            p.marca,
            p.dieta,
            p.url_imagen,
            p.categoria_id,
            c.nombre AS categoria_nombre,
            c.slug AS categoria_slug
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        ORDER BY precio ASC
        """
        productos_db = db.execute_query(query)
        logger.info(f"Productos obtenidos de BD: {len(productos_db) if productos_db else 0}")
        if productos_db and len(productos_db) > 0:
            # Normalizar precios DECIMAL a float para evitar conflictos con operaciones aritméticas
            productos_normalizados = []
            for p in productos_db:
                try:
                    pn = dict(p)
                    if pn.get('precio') is not None:
                        pn['precio'] = float(pn['precio'])
                    categoria_nombre = pn.get('categoria_nombre') or pn.get('categoria')
                    categoria_slug = pn.get('categoria_slug')
                    if categoria_nombre and not categoria_slug:
                        categoria_slug = categoria_nombre.lower().replace(' ', '-')
                    pn['categoria_nombre'] = categoria_nombre
                    pn['categoria_slug'] = categoria_slug
                    pn['categoria'] = categoria_nombre or ''
                    productos_normalizados.append(pn)
                except Exception:
                    # Si algún registro falla, se omite para no romper toda la respuesta
                    continue
            return productos_normalizados
        # Si la consulta no retorna productos, significa que la tabla está vacía
        logger.error("La tabla productos está vacía")
        return []
    except Exception as e:
        logger.error(f"Error conectando a la base de datos: {e}")
        logger.error("NO se usarán productos de ejemplo - el sistema requiere conexión a BD")
        # NO retornar productos de ejemplo - retornar lista vacía
        return []

def obtener_historial_usuario(usuario_id: int) -> List[Dict]:
    """Obtiene el historial de compras del usuario para mejorar recomendaciones"""
    try:
        query = """
        SELECT producto_id, COUNT(*) as frecuencia
        FROM canasta_detalle cd
        INNER JOIN canastas c ON c.id = cd.canasta_id
        WHERE c.usuario_id = %s
        GROUP BY producto_id
        ORDER BY frecuencia DESC
        LIMIT 10
        """
        result = db.execute_query(query, (usuario_id,))
        return [item['producto_id'] for item in result] if result else []
    except Exception as e:
        logger.error(f"Error obteniendo historial: {e}")
        # Retornar historial simulado para testing
        return [1, 2, 3, 7, 11]  # Productos más comprados por defecto

def aplicar_filtros_preferencias(productos: List[Dict], preferencias: Dict = None) -> List[Dict]:
    """Aplica filtros basados en las preferencias del usuario"""
    if not preferencias:
        return productos
    
    productos_filtrados = productos.copy()
    
    # Filtrar por marcas preferidas (priorizar, no forzar)
    if preferencias.get('marcas_preferidas') and len(preferencias['marcas_preferidas']) > 0:
        marcas_preferidas = [m.lower() for m in preferencias['marcas_preferidas']]
        productos_con_marca = [p for p in productos_filtrados if p.get('marca') and p['marca'].lower() in marcas_preferidas]
        # Si hay productos con la marca preferida, priorizarlos pero agregar más productos también
        if len(productos_con_marca) > 0:
            # Agregar productos de marca preferida AL INICIO
            otros_productos = [p for p in productos_filtrados if p not in productos_con_marca]
            productos_filtrados = productos_con_marca + otros_productos
    
    # Filtrar por dietas (solo excluir productos NO compatibles)
    if preferencias.get('dietas') and len(preferencias['dietas']) > 0:
        dietas = [d.lower() for d in preferencias['dietas']]
        productos_filtrados = [
            p for p in productos_filtrados 
            if not p.get('dieta') or p['dieta'].lower() in dietas  # Productos sin dieta o con dieta compatible
        ]
    
    # Excluir categorías
    if preferencias.get('categorias_excluidas'):
        categorias_excluidas = [c.lower() for c in preferencias['categorias_excluidas']]
        productos_filtrados = [
            p for p in productos_filtrados 
            if all(
                (valor or '').lower() not in categorias_excluidas
                for valor in [
                    p.get('categoria'),
                    p.get('categoria_nombre'),
                    p.get('categoria_slug')
                ]
            )
        ]
    
    # Asegurar que hay productos disponibles
    if len(productos_filtrados) == 0:
        logger.warning("No hay productos con las preferencias, usando todos los productos")
        return productos
    
    return productos_filtrados

def generar_recomendaciones_ia(productos: List[Dict], canasta_actual: List[Dict], presupuesto_restante: float, usuario_id: int, historial: List[int] = None) -> List[Dict]:
    """
    Genera recomendaciones usando algoritmo de IA simple
    """
    logger.info(f"Iniciando generación de recomendaciones - Productos disponibles: {len(productos)}, Presupuesto: {presupuesto_restante}")
    
    if presupuesto_restante <= 0:
        logger.warning("Presupuesto restante es 0 o negativo")
        return []
    
    # Obtener categorías ya incluidas en la canasta
    categorias_incluidas = set(p.get('categoria', '') for p in canasta_actual)
    logger.info(f"Categorías incluidas: {categorias_incluidas}")
    
    # Algoritmo de recomendación basado en:
    # 1. Diversidad de categorías
    # 2. Precio accesible
    # 3. Popularidad (simulada)
    
    recomendaciones = []
    
    # Si no hay productos, devolver lista vacía
    if len(productos) == 0:
        logger.error("No hay productos disponibles para recomendar")
        return []
    
    # Ordenar productos por precio (más baratos primero)
    productos_ordenados = sorted(productos, key=lambda x: x['precio'])
    
    # Agregar productos hasta llenar el presupuesto
    for producto in productos_ordenados:
        if producto['precio'] <= presupuesto_restante:
            recomendaciones.append({
                **producto,
                'es_deseado': False,
                'score_relevancia': 0.8
            })
            presupuesto_restante -= producto['precio']
            if len(recomendaciones) >= 20:  # Limitar a 20 productos
                break
    
    return recomendaciones

def calcular_score_relevancia(producto: Dict, canasta_actual: List[Dict], usuario_id: int, historial: List[int] = None) -> float:
    """Calcula un score de relevancia para el producto"""
    score = 0.5  # Score base
    
    # Bonus por diversidad de categorías
    categorias_actuales = [p.get('categoria', '') for p in canasta_actual]
    if producto.get('categoria', '') not in categorias_actuales:
        score += 0.3
    
    # Bonus por precio accesible (productos más baratos tienen mayor score)
    if producto['precio'] < 10:
        score += 0.2
    elif producto['precio'] < 25:
        score += 0.1
    
    # Bonus por disponibilidad de stock
    if producto.get('stock', 0) > 10:
        score += 0.1
    
    # Bonus por historial de compras del usuario
    if historial and producto['id'] in historial:
        score += 0.5  # Productos comprados frecuentemente - más peso
        # Productos en el top 3 del historial tienen aún más peso
        top_3_historial = historial[:3]
        if producto['id'] in top_3_historial:
            score += 0.2
    
    # Bonus por marcas preferidas
    if producto.get('marca') in ['Nestlé', 'Coca-Cola', 'P&G']:
        score += 0.1
    
    return min(1.0, score)

def crear_respuesta_vacia(presupuesto: float) -> Dict[str, Any]:
    """Crea una respuesta vacía cuando no se pueden generar recomendaciones"""
    return {
        "productos": [],
        "total": 0.0,
        "presupuesto": presupuesto,
        "ahorro": presupuesto,
        "porcentaje_ahorro": 100.0,
        "productos_recomendados": 0,
        "productos_deseados": 0
    }
