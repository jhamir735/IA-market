
## Comandos para Inicializar el Backend

### Backend FastAPI (Python)

```bash
# Navegar al directorio del backend
cd "Avance2 marco web\Marcos web avance 2\backend-ia\backend-ia"

# Iniciar el servidor FastAPI
python main.py
```

El backend se ejecutará en: `http://localhost:3000`

### Verificar que el Backend está Corriendo

```bash
# Verificar salud del servicio
curl http://localhost:3000/health
```

Debería retornar:
```json
{
  "status": "healthy",
  "service": "Supermercado IA API",
  "version": "1.0.0"
}
```