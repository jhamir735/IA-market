// js/products.js - Base de datos de prueba para el Prototipo Visual

const productDatabase = [
    // --- ABARROTES ---
    {
        id: 1,
        name: "Arroz Extra Costeño 5kg",
        price: 24.30,
        category: "abarrotes",
        brand: "Costeño",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/27901764-1000-1000/20054705.jpg"
    },
    {
        id: 2,
        name: "Aceite Vegetal Primor Premium 1L",
        price: 8.90,
        category: "abarrotes",
        brand: "Primor",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/519391-1000-1000/20138981.jpg"
    },
    {
        id: 3,
        name: "Fideos Spaghetti Don Vittorio 1kg",
        price: 5.20,
        category: "abarrotes",
        brand: "Don Vittorio",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/27898863-1000-1000/356191.jpg"
    },
    // --- LÁCTEOS ---
    {
        id: 4,
        name: "Leche Evaporada Gloria Azul Six Pack",
        price: 21.90,
        category: "lacteos",
        brand: "Gloria",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/27914041-1000-1000/989182.jpg"
    },
    {
        id: 5,
        name: "Yogurt Gloria Batido Fresa 1kg",
        price: 6.50,
        category: "lacteos",
        brand: "Gloria",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/27926978-1000-1000/20063255.jpg"
    },
    // --- BEBIDAS ---
    {
        id: 6,
        name: "Gaseosa Inca Kola 3L",
        price: 11.50,
        category: "bebidas",
        brand: "Inca Kola",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/27898932-1000-1000/gaseosa-inca-kola-botella-3l_1.jpg"
    },
    {
        id: 7,
        name: "Agua San Mateo Sin Gas 2.5L",
        price: 3.90,
        category: "bebidas",
        brand: "San Mateo",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/176043-1000-1000/20042735.jpg"
    },
    // --- LIMPIEZA ---
    {
        id: 8,
        name: "Detergente Bolívar Flores de Manzano 2kg",
        price: 18.90,
        category: "limpieza",
        brand: "Bolívar",
        img: "https://plazavea.vteximg.com.br/arquivos/ids/28220038-1000-1000/20268453.jpg"
    },
    // --- FRUTAS Y VERDURAS ---
    {
        id: 9,
        name: "Plátano de Seda (kg)",
        price: 3.20,
        category: "frescos",
        brand: "Mercado",
        img: "https://images.unsplash.com/photo-1571771894821-ad9b6867a063?q=80&w=300&h=300&auto=format&fit=crop"
    }
];

// Datos auxiliares para filtros estáticos
const catalogCategories = [
    {id: 1, nombre: "Abarrotes", slug: "abarrotes"},
    {id: 2, nombre: "Lácteos y Huevos", slug: "lacteos"},
    {id: 3, nombre: "Bebidas", slug: "bebidas"},
    {id: 4, nombre: "Limpieza", slug: "limpieza"},
    {id: 5, nombre: "Frutas y Verduras", slug: "frescos"}
];

// Avisar al sistema que los productos están cargados (para simulaciones)
window.dispatchEvent(new CustomEvent('productsLoaded', { detail: { productos: productDatabase } }));
window.dispatchEvent(new CustomEvent('categoriesLoaded', { detail: { categories: catalogCategories } }));